import azure.functions as func
import logging
import subprocess   
import os
app = func.FunctionApp(http_auth_level=func.AuthLevel.FUNCTION)

## This function is used to prep the data for the search service
@app.route(route="http_trigger")
def http_trigger(req: func.HttpRequest) -> func.HttpResponse:
    try:
        AZURE_ADLS_GEN2_FILESYSTEM=os.environ["AZURE_ADLS_GEN2_FILESYSTEM"] 
        AZURE_ADLS_GEN2_STORAGE_ACCOUNT=os.environ["AZURE_ADLS_GEN2_STORAGE_ACCOUNT"]
        AZURE_FORMRECOGNIZER_SERVICE=os.environ["AZURE_FORMRECOGNIZER_SERVICE"]
        AZURE_OPENAI_EMB_DEPLOYMENT=os.environ["AZURE_OPENAI_EMB_DEPLOYMENT"]
        AZURE_OPENAI_EMB_MODEL_NAME=os.environ["AZURE_OPENAI_EMB_MODEL_NAME"]
        AZURE_OPENAI_SERVICE=os.environ["AZURE_OPENAI_SERVICE"]
        AZURE_SEARCH_INDEX=os.environ["AZURE_SEARCH_INDEX"]
        AZURE_SEARCH_SERVICE=os.environ["AZURE_SEARCH_SERVICE"]
        AZURE_STORAGE_ACCOUNT=os.environ["AZURE_STORAGE_ACCOUNT"]
        AZURE_STORAGE_CONTAINER=os.environ["AZURE_STORAGE_CONTAINER"]
        AZURE_TENANT_ID=os.environ["AZURE_TENANT_ID"]
        OPENAI_API_KEY=os.environ.get("OPENAI_API_KEY", "")
        OPENAI_HOST=os.environ["OPENAI_HOST"]
        command1=["python3","-m","pip","install","-r","./requirements.txt"]
        subprocess.run(command1, check=True)
        command2= [
        "python3",
        "./scripts/prepdocs.py",
        "'./data/*'",
        "--datalakestorageaccount",AZURE_ADLS_GEN2_STORAGE_ACCOUNT,
        "--datalakefilesystem",AZURE_ADLS_GEN2_FILESYSTEM,
        "--datalakepath","",
        "--useacls",
        "--storageaccount", AZURE_STORAGE_ACCOUNT,
        "--container", AZURE_STORAGE_CONTAINER,
        "--searchservice", AZURE_SEARCH_SERVICE,
        "--openaiservice", AZURE_OPENAI_SERVICE,
        "--openaideployment", AZURE_OPENAI_EMB_DEPLOYMENT,
        "--openaimodelname", AZURE_OPENAI_EMB_MODEL_NAME,
        "--index", AZURE_SEARCH_INDEX,
        "--formrecognizerservice", AZURE_FORMRECOGNIZER_SERVICE,
        "--tenantid", AZURE_TENANT_ID,
        "--openaihost", OPENAI_HOST,
        "--openaikey", OPENAI_API_KEY,
        "-v"

        ]
        subprocess.run(command2, check=True)
        ###Move pdfs to indexedpdf container
        command3=[
        "python3",
        "./scripts/prepdocslib/pdfmover.py"
        ]
        subprocess.run(command3, check=True)

        return func.HttpResponse(f"Data prepped successfully")
    except Exception as e:
        logging.error(f"Error: {e}")
        return func.HttpResponse(f"Error: {e}", status_code=500)