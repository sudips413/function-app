import os
from azure.storage.blob import BlobServiceClient, BlobClient
from azure.identity import DefaultAzureCredential

# import the Azure Storage Account name
account_name = os.environ["AZURE_ADLS_GEN2_STORAGE_ACCOUNT"]

def move_blobs(source_container, destination_container):
    # Create a BlobServiceClient using DefaultAzureCredential
    blob_service_client = BlobServiceClient(account_url=f"https://{account_name}.blob.core.windows.net/", credential=DefaultAzureCredential())

    # Create a client for the source container
    source_container_client = blob_service_client.get_container_client(source_container)

    # Create a client for the destination container
    destination_container_client = blob_service_client.get_container_client(destination_container)

    # List blobs in the source container
    blobs = source_container_client.list_blobs()

    # Move (copy and then delete) each blob to the destination container
    for blob in blobs:
        source_blob_client = source_container_client.get_blob_client(blob.name)
        destination_blob_client = destination_container_client.get_blob_client(blob.name)

        # Copy blob
        destination_blob_client.start_copy_from_url(source_blob_client.url)

        # Delete blob from the source container
        source_blob_client.delete_blob()

    return f"Blobs moved from {source_container} to {destination_container}"

def main(req):
    source_container = "pdf"
    destination_container = "indexedpdf"

    result = move_blobs(source_container, destination_container)
    return result

main("")
